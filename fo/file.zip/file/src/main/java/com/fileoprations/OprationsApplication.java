package com.fileoprations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OprationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(OprationsApplication.class, args);
	}

}
